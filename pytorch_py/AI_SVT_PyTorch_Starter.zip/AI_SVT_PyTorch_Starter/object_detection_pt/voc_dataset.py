import os
import glob
import xml.etree.ElementTree as ET
from PIL import Image
import torch
from torch.utils.data import Dataset

def parse_voc_xml(xml_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()
    boxes = []
    labels = []
    # support either <name> text string labels with a mapping provided by labels.json
    for obj in root.findall("object"):
        name = obj.find("name").text
        bnd = obj.find("bndbox")
        xmin = float(bnd.find("xmin").text)
        ymin = float(bnd.find("ymin").text)
        xmax = float(bnd.find("xmax").text)
        ymax = float(bnd.find("ymax").text)
        boxes.append([xmin, ymin, xmax, ymax])
        labels.append(name)
    width = int(root.find("size").find("width").text)
    height = int(root.find("size").find("height").text)
    return boxes, labels, (width, height)

class VOCDataset(Dataset):
    """
    Minimal Pascal VOC-style dataset that reads:
      - images_dir: folder of images (jpg/png)
      - annos_dir:  folder of VOC XML files, one per image
    Label mapping comes from a 'labels.json' file at --labels_json path:
        {
          "background": 0,
          "Dent": 1,
          "Scratch": 2,
          "Crack": 3,
          "Other": 4
        }
    (background MUST be 0; class ids must be contiguous 1..N)
    """
    def __init__(self, images_dir, annos_dir, labels_json, transforms=None, image_exts=(".jpg",".jpeg",".png",".bmp")):
        self.images_dir = images_dir
        self.annos_dir  = annos_dir
        self.labels = json_load(labels_json)
        self.name2id = self.labels
        # reverse map id->name (excluding background 0 for convenience)
        self.id2name = {v:k for k,v in self.name2id.items()}
        self.transforms = transforms
        # index XMLs, keep only those with matching image
        xmls = sorted(glob.glob(os.path.join(self.annos_dir, "*.xml")))
        self.samples = []
        for x in xmls:
            stem = os.path.splitext(os.path.basename(x))[0]
            img_path = None
            for ext in image_exts:
                p = os.path.join(self.images_dir, stem + ext)
                if os.path.isfile(p):
                    img_path = p
                    break
            if img_path:
                self.samples.append((img_path, x))
        if len(self.samples) == 0:
            raise FileNotFoundError(f"No (image, xml) pairs found under {images_dir} / {annos_dir}")
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        img_path, xml_path = self.samples[idx]
        img = Image.open(img_path).convert("RGB")
        boxes_xyxy, label_names, _ = parse_voc_xml(xml_path)

        # map label names to ids
        labels = []
        for n in label_names:
            if n not in self.name2id:
                raise KeyError(f"Label '{n}' not found in labels.json")
            labels.append(self.name2id[n])
        # empty boxes edge-case
        if len(boxes_xyxy) == 0:
            boxes = torch.zeros((0,4), dtype=torch.float32)
            labels_t = torch.zeros((0,), dtype=torch.int64)
        else:
            boxes = torch.tensor(boxes_xyxy, dtype=torch.float32)
            labels_t = torch.tensor(labels, dtype=torch.int64)

        target = {
            "boxes": boxes,
            "labels": labels_t,
            "image_id": torch.tensor([idx])
        }
        if self.transforms:
            img = self.transforms(img)
        # torchvision models expect C,H,W tensor float [0..1]
        import torchvision.transforms as T
        if not isinstance(img, torch.Tensor):
            img = T.ToTensor()(img)
        return img, target

def json_load(p):
    import json
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def collate_fn(batch):
    # batch is list of (img, target). Need to return tuple(list[Tensor], list[Dict])
    imgs = [b[0] for b in batch]
    targets = [b[1] for b in batch]
    return imgs, targets
