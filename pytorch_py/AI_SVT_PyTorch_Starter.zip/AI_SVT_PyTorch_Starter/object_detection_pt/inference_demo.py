# Quick demo script to run inference on a folder of images using the exported artifacts.
import os, glob, argparse, json, pprint

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images_dir", required=True)
    ap.add_argument("--export_dir", default="output_inference_graph/saved_model")
    ap.add_argument("--score_thresh", type=float, default=0.5)
    args = ap.parse_args()

    infer_py = os.path.join(args.export_dir, "inference.py")
    if not os.path.isfile(infer_py):
        raise FileNotFoundError(f"inference.py not found under {args.export_dir}; run export first.")

    import importlib.util
    spec = importlib.util.spec_from_file_location("pt_infer", infer_py)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    images = []
    for ext in ("*.jpg","*.jpeg","*.png","*.bmp"):
        images.extend(glob.glob(os.path.join(args.images_dir, ext)))
    images = sorted(images)
    print(f"[INFO] Found {len(images)} images")

    for p in images:
        res = mod.predict(p, score_thresh=args.score_thresh)
        print(os.path.basename(p))
        pprint.pprint(res[:5])

if __name__ == "__main__":
    main()
