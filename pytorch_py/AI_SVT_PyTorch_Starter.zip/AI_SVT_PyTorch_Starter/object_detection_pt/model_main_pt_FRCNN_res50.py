# PyTorch Faster R-CNN ResNet50-FPN training loop
# Mirrors TF-style workflow: TensorBoard logs, step-based training, checkpoints,
# and "0.7 point" best checkpoint snapshot (best_at_0.7.pth).

import os
import json
import time
import argparse
import torch
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from torchvision.models.detection import fasterrcnn_resnet50_fpn
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor

from voc_dataset import VOCDataset, collate_fn
from utils import SmoothedValue, save_checkpoint, format_seconds

def build_model(num_classes, pretrained=True):
    # Load COCO-pretrained backbone+head, then replace predictor with our num_classes
    model = fasterrcnn_resnet50_fpn(weights="DEFAULT" if pretrained else None)
    in_features = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes)
    return model

def parse_args():
    p = argparse.ArgumentParser()
    # Data
    p.add_argument("--images_dir", required=True, help="Path to images folder")
    p.add_argument("--annos_dir", required=True, help="Path to VOC XML folder")
    p.add_argument("--labels_json", required=True, help="labels.json path (with background:0)")
    # Training schedule (step-based to mirror TF behavior)
    p.add_argument("--max_steps", type=int, default=10000, help="Total optimizer steps")
    p.add_argument("--batch_size", type=int, default=2)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--ckpt_interval", type=int, default=1000, help="Save ckpt every N steps")
    # Optimizer / HPs
    p.add_argument("--lr", type=float, default=0.005)
    p.add_argument("--momentum", type=float, default=0.9)
    p.add_argument("--weight_decay", type=float, default=0.0005)
    p.add_argument("--lr_gamma", type=float, default=0.1)
    p.add_argument("--lr_step", type=int, default=8000, help="StepLR milestone in steps")
    # I/O
    p.add_argument("--train_result", default="train_result_pt", help="TensorBoard logdir")
    p.add_argument("--ckpt_dir", default="train_result_pt/ckpts")
    p.add_argument("--device", default="cuda")
    p.add_argument("--resume", default="", help="Path to ckpt to resume from")
    p.add_argument("--save_every_image_vis", action="store_true", help="Log images with boxes intermittently")
    # 0.7 checkpoint logic
    p.add_argument("--save_best_at_0p7", action="store_true", help="At step>=0.7*max_steps, save best_at_0.7.pth on improvement")
    return p.parse_args()

def main():
    args = parse_args()
    os.makedirs(args.train_result, exist_ok=True)
    os.makedirs(args.ckpt_dir, exist_ok=True)

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    print(f"[Device] {device}   (CUDA available: {torch.cuda.is_available()})")

    dataset = VOCDataset(args.images_dir, args.annos_dir, args.labels_json)
    num_classes = max(dataset.id2name.keys()) + 1  # background=0, classes 1..N
    print(f"[Dataset] {len(dataset)} images  /  classes={num_classes-1}  (labels.json background+{num_classes-1} classes)")

    data_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True,
                             num_workers=args.num_workers, collate_fn=collate_fn)

    model = build_model(num_classes=num_classes).to(device)

    params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.SGD(params, lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[args.lr_step], gamma=args.lr_gamma)

    # TensorBoard
    writer = SummaryWriter(log_dir=args.train_result)
    # try to add graph once
    try:
        import torchvision.transforms as T
        from PIL import Image
        img0, _ = dataset[0]
        if img0.ndim == 3:
            writer.add_graph(model, (img0.unsqueeze(0).to(device),))
    except Exception as e:
        print(f"[WARN] add_graph failed: {e}")

    step = 0
    best_loss = float("inf")
    loss_ema = SmoothedValue()
    start_time = time.time()
    model.train()

    # If resume
    if args.resume and os.path.isfile(args.resume):
        print(f"[Resume] Loading: {args.resume}")
        state = torch.load(args.resume, map_location="cpu")
        model.load_state_dict(state["model"], strict=False)
        optimizer.load_state_dict(state["optimizer"])
        step = state.get("step", 0)
        best_loss = state.get("best_loss", float("inf"))
        print(f"[Resume] step={step}, best_loss={best_loss:.6f}")

    dl_iter = iter(data_loader)
    while step < args.max_steps:
        try:
            imgs, targets = next(dl_iter)
        except StopIteration:
            dl_iter = iter(data_loader)
            imgs, targets = next(dl_iter)

        imgs = [im.to(device) for im in imgs]
        targets = [{k: v.to(device) for k,v in t.items()} for t in targets]

        loss_dict = model(imgs, targets)
        losses = sum(loss for loss in loss_dict.values())

        optimizer.zero_grad(set_to_none=True)
        losses.backward()
        optimizer.step()

        step += 1
        loss_val = float(losses.detach().cpu())
        ema = loss_ema.update(loss_val)
        lr_now = optimizer.param_groups[0]["lr"]

        # TB logs
        if step % 10 == 0 or step == 1:
            writer.add_scalar("train/loss_total", loss_val, step)
            writer.add_scalar("train/loss_ema", ema, step)
            writer.add_scalar("train/lr", lr_now, step)

        if step % 100 == 0 or step == 1:
            elapsed = time.time() - start_time
            eta = (args.max_steps - step) * (elapsed / max(step,1))
            print(f"[{step:6d}/{args.max_steps}] loss={loss_val:.4f} ema={ema:.4f} lr={lr_now:.5f} | elapsed {format_seconds(elapsed)} ETA {format_seconds(eta)}")

        if step % args.ckpt_interval == 0 or step == args.max_steps:
            is_best = ema < best_loss
            if is_best:
                best_loss = ema
            # 0.7 logic
            best_at_07 = False
            if args.save_best_at_0p7 and step >= int(0.7 * args.max_steps) and is_best:
                best_at_07 = True
            save_checkpoint({
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "step": step,
                "best_loss": best_loss,
                "labels_json": os.path.abspath(args.labels_json),
                "num_classes": num_classes
            }, args.ckpt_dir, step, is_best=is_best, best_at_07=best_at_07)

        # LR step on schedule
        if step == args.lr_step:
            scheduler.step()

    writer.close()
    print("[DONE] Training finished.")
    # final save (alias)
    save_checkpoint({
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "step": step,
        "best_loss": best_loss,
        "labels_json": os.path.abspath(args.labels_json),
        "num_classes": num_classes
    }, args.ckpt_dir, step, is_best=True, best_at_07=True)

if __name__ == "__main__":
    main()
