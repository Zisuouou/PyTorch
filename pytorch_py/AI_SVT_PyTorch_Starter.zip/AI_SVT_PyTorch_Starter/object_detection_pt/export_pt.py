# Export checkpoints to a "saved_model" style folder hierarchy
# to mirror TF: output_inference_graph/saved_model/*
import os
import json
import argparse
import shutil
import torch

from torchvision.models.detection import fasterrcnn_resnet50_fpn
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor

def load_labels(labels_json_path):
    with open(labels_json_path, "r", encoding="utf-8") as f:
        return json.load(f)

def build_model(num_classes):
    m = fasterrcnn_resnet50_fpn(weights=None)
    in_features = m.roi_heads.box_predictor.cls_score.in_features
    m.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes)
    return m

def export_from_ckpt(ckpt_path, output_dir="output_inference_graph/saved_model", script_input_size=800):
    if not os.path.isfile(ckpt_path):
        raise FileNotFoundError(f"Not found: {ckpt_path}")
    state = torch.load(ckpt_path, map_location="cpu")
    num_classes = int(state.get("num_classes", 2))
    labels_json = state.get("labels_json", None)
    if labels_json is None or not os.path.isfile(labels_json):
        raise FileNotFoundError("labels_json path missing inside checkpoint; set when training or pass --labels_json to re-export.")

    labels = load_labels(labels_json)
    os.makedirs(output_dir, exist_ok=True)

    # build & load
    model = build_model(num_classes)
    model.load_state_dict(state["model"], strict=False)
    model.eval()

    # save raw state_dict
    state_path = os.path.join(output_dir, "model_state_dict.pth")
    torch.save(model.state_dict(), state_path)

    # TorchScript (trace with dummy input)
    dummy = torch.randn(1, 3, script_input_size, script_input_size)
    with torch.no_grad():
        scripted = torch.jit.trace(model, dummy)
    script_path = os.path.join(output_dir, "model_scripted.pt")
    scripted.save(script_path)

    # copy labels + minimal pipeline meta
    shutil.copy2(labels_json, os.path.join(output_dir, "labels.json"))
    meta = {
        "framework": "pytorch",
        "arch": "fasterrcnn_resnet50_fpn",
        "script_input_size": script_input_size,
        "num_classes": num_classes
    }
    with open(os.path.join(output_dir, "pipeline.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)

    # write a tiny inference helper next to the artifacts
    infer_py = os.path.join(output_dir, "inference.py")
    with open(infer_py, "w", encoding="utf-8") as f:
        f.write(f"""# Inference helper for exported PyTorch Faster R-CNN
import os, json
import torch
from PIL import Image
from torchvision.transforms import functional as F

BASE = os.path.dirname(__file__)
SCRIPTED = os.path.join(BASE, "model_scripted.pt")
LABELS  = os.path.join(BASE, "labels.json")

with open(LABELS, "r", encoding="utf-8") as f:
    labels = json.load(f)
id2name = {{v:k for k,v in labels.items()}}

model = torch.jit.load(SCRIPTED, map_location="cpu").eval()

def predict(image_path, score_thresh=0.5):
    img = Image.open(image_path).convert("RGB")
    timg = F.to_tensor(img).unsqueeze(0)
    with torch.no_grad():
        out = model(timg)[0]
    boxes = out["boxes"].tolist()
    scores = out["scores"].tolist()
    labs = out["labels"].tolist()
    results = []
    for b,s,l in zip(boxes, scores, labs):
        if s < score_thresh: 
            continue
        results.append({{"box": b, "score": float(s), "label_id": int(l), "label_name": id2name.get(int(l), str(l))}})
    return results

if __name__ == "__main__":
    import sys, pprint
    img = sys.argv[1]
    print(predict(img))
""")

    # readme
    with open(os.path.join(output_dir, "README.txt"), "w", encoding="utf-8") as f:
        f.write("This folder mirrors TF's saved_model style for convenience. Use inference.py for quick tests.\n")

    print(f"[EXPORTED] {ckpt_path} -> {output_dir}")
    print(f"  - state_dict : {state_path}")
    print(f"  - scripted   : {script_path}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", help="Path to checkpoint .pth (e.g., train_result_pt/ckpts/best.pth)")
    ap.add_argument("--use_best", action="store_true", help="Shortcut for 'best.pth' under --ckpt_dir")
    ap.add_argument("--use_best07", action="store_true", help="Shortcut for 'best_at_0.7.pth' under --ckpt_dir")
    ap.add_argument("--ckpt_dir", default="train_result_pt/ckpts")
    ap.add_argument("--output_dir", default="output_inference_graph/saved_model")
    ap.add_argument("--script_input_size", type=int, default=800)
    args = ap.parse_args()

    if args.ckpt:
        ck = args.ckpt
    else:
        if args.use_best:
            ck = os.path.join(args.ckpt_dir, "best.pth")
        elif args.use_best07:
            ck = os.path.join(args.ckpt_dir, "best_at_0.7.pth")
        else:
            ck = os.path.join(args.ckpt_dir, "latest.pth")
    export_from_ckpt(ck, output_dir=args.output_dir, script_input_size=args.script_input_size)

if __name__ == "__main__":
    main()
