import os
import shutil
import time
import torch

class SmoothedValue:
    def __init__(self, momentum=0.98):
        self.momentum = momentum
        self.val = None
    
    def update(self, x):
        x = float(x)
        if self.val is None:
            self.val = x
        else:
            self.val = self.momentum * self.val + (1 - self.momentum) * x
        return self.val

def save_checkpoint(state, ckpt_dir, step, is_best=False, best_at_07=False):
    os.makedirs(ckpt_dir, exist_ok=True)
    path = os.path.join(ckpt_dir, f"ckpt_step{step}.pth")
    torch.save(state, path)
    # update pointers
    latest = os.path.join(ckpt_dir, "latest.pth")
    shutil.copy2(path, latest)
    if is_best:
        bestp = os.path.join(ckpt_dir, "best.pth")
        shutil.copy2(path, bestp)
    if best_at_07:
        best07 = os.path.join(ckpt_dir, "best_at_0.7.pth")
        shutil.copy2(path, best07)

def format_seconds(sec):
    m, s = divmod(int(sec), 60)
    h, m = divmod(m, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"
